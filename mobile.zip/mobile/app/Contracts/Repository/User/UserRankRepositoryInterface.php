<?php
//多点乐资源
namespace App\Contracts\Repository\User;

interface UserRankRepositoryInterface
{}


?>
