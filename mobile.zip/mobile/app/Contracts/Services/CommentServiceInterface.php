<?php
//多点乐资源
namespace App\Contracts\Services;

interface CommentServiceInterface
{
	public function query();

	public function count();
}


?>
