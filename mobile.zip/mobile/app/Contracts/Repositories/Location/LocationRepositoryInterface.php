<?php
//多点乐资源
namespace App\Contracts\Repositories\Location;

interface LocationRepositoryInterface
{}


?>
