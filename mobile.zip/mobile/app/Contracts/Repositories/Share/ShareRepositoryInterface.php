<?php
//多点乐
namespace App\Contracts\Repositories\Share;

interface ShareRepositoryInterface
{}


?>
