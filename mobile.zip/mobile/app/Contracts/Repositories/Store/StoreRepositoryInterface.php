<?php
//多点乐资源
namespace App\Contracts\Repositories\Store;

interface StoreRepositoryInterface
{}


?>
