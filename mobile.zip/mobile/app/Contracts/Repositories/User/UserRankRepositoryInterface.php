<?php
//多点乐资源
namespace App\Contracts\Repositories\User;

interface UserRankRepositoryInterface
{}


?>
