<?php
//多点乐
namespace App\Contracts\Repositories\Coupons;

interface CouponsRepositoryInterface
{}


?>
