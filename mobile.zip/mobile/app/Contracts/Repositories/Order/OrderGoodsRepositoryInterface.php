<?php
//多点乐资源
namespace App\Contracts\Repositories\Order;

interface OrderGoodsRepositoryInterface
{}


?>
