<?php
//多点乐资源
namespace App\Custom\Site\Controllers;

class IndexController extends \App\Modules\Site\Controllers\IndexController
{
	public function actionAbout()
	{
		$this->display();
	}

	public function actionPhpinfo()
	{
	}
}

?>
