<?php
//多点乐资源
namespace App\Api\Requests;

class SearchGoods
{}


?>
