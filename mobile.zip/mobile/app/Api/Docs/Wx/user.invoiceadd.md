##api/wx/user/invoice/add  用户添加增值发票

####链接
     http://10.10.10.145/dsc/mobile/public/api/wx/user/invoice/add


#### 参数
参数由  微信获取

####头部参数
1. x-ectouch-authorization     参数名



####返回参数
1. code : 0 为正常   **1 为不正常**
2. code :0 ,data为false 改用户已经有增值发票了


