##api/wx/region/list  订单列表

####链接
     http://domain/mobile/public/api/wx/region/list

####参数
1. id   1 地区ID

####返回参数
1. code : 0 为正常   **1 为不正常**
2. data  : 数据 （数组）
    > 1. region_id: 36,   地区ID
    > 2. parent_id: 3,    父ID
    > 3. region_name: "安庆"    地区名
    > 4. region_type: 2,    地区类型
    > 5. agency_id: 0  

