##api/wx/user/address/delete  删除收货地址

####链接
     http://domain/mobile/public/api/wx/user/address/delete

####参数
1. id  收货地址ID

####头部参数
1. x-ectouch-authorization     参数名
2.    参数值

####返回参数
1. code : 0 为正常   **1 为不正常**
2. data  : 数据 （数组）
    > 1. true
