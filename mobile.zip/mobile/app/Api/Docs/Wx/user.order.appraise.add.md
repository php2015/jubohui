##api/wx/user/order/appraise/add  待评价详情

####链接
     http://domain/mobile/public/api/wx/user/order/appraise/add

####参数
1. oid   1 订单ID
2. gid   10  商品ID
3. content  内容
4. rank  等级

####头部参数
1. x-ectouch-authorization     参数名
2.    参数值


####返回参数
1. code : 0 为正常   **1 为不正常**
2. data  : true   添加成功

