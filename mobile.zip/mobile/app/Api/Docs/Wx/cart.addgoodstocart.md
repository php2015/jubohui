##api/wx/cart/add   添加购物车商品


####链接
    http://10.10.10.145/dsc/mobile/public/api/wx/cart/add

####参数
1. method   ecapi.wx.cart.addgoodstocart
2. id:700    //商品ID
3. num:3     //商品数量
4. goods_attr   // 属性值  （可选）


####头部参数
1. x-ectouch-authorization     参数名
2.    参数值


####返回参数
1. code : 0 为正常   **1 为不正常**
2. data  : true  （bool）  
