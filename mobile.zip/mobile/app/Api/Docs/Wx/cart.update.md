##api/wx/cart/update   更新购物车商品
    > headers  : x-ectouch-authorization
    > 参数   ： id   商品id


####链接
    http://domain/mobile/public/api/wx/cart/update

####参数
1. id:62    //购物车ID
2. amount:3     //商品数量


####头部参数
1. x-ectouch-authorization     参数名
2.    参数值


####返回参数
1. code : 0 为正常   **1 为不正常**
2. data  : 添加成功  （文字）  
