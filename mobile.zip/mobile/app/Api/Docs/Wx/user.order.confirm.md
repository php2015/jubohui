##api/wx/user/order/confirm  取消订单

####链接
     http://domain/mobile/public/api/wx/user/order/confirm

####参数
1.  id   订单ID

####头部参数
1. x-ectouch-authorization     参数名
2.    参数值


####返回参数
1. code : 0 为正常   **1 为不正常**
2. data  ： true   确认成功  （ 不成功则返回错误信息 ）