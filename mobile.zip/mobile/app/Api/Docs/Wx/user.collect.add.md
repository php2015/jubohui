##api/wx/user/collect/add   我的收藏


####链接
    http://domain/mobile/public/api/wx/user/collect/add

####参数
1. id  商品ID


####头部参数
1. x-ectouch-authorization     参数名
2.    参数值


####返回参数
1. code : 0 为正常   **1 为不正常**
2. data  true   成功