##api/wx/cart/delete   删除购物车商品

####链接
    http://domain/mobile/public/api/wx/cart/delete

####参数
1. id:700    //购物车ID

####头部参数
1. x-ectouch-authorization     参数名
2.    参数值


####返回参数
1. code : 0 为正常   **1 为不正常**
2. data  : 消息  
