##api/wx/user/invoice/delete  用户增值发票详情

####链接
     http://10.10.10.145/dsc/mobile/public/api/wx/user/invoice/delete


#### 参数
id : 增值发票的id

####头部参数
1. x-ectouch-authorization     参数名



####返回参数
1. code : 0 为正常   **1 为不正常**


