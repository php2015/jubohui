##api/wx/payment/notify  支付接口

####链接
     http://domain/mobile/public/api/wx/payment/notify

####参数
    > 参数   ： id  订单ID

####头部参数
1. x-ectouch-authorization     参数名
2.    参数值


####返回参数
1. code : 0 为正常   **1 为不正常**
2. data  : 1   (错误则返回错误信息)