<?php
//多点乐资源
namespace app\api\v2\category\transformer;

class CategoryTransformer extends \App\Api\Foundation\Transformer
{
	public function transform(array $map)
	{
		return array();
	}
}

?>
