<?php
//多点乐资源
namespace app\api\v2\goods\transformer;

class Goods extends \app\api\foundation\Transformer
{
	public function transform(array $map)
	{
		return array();
	}
}

?>
