<?php
//多点乐资源
namespace app\api\v2\goods\controllers;

class Sku extends \app\api\v2\Controller
{
	public function actionList()
	{
	}

	public function actionDetail()
	{
	}

	public function actionSku()
	{
	}

	public function actionFittings()
	{
	}
}

?>
