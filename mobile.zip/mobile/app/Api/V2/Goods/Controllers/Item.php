<?php
//多点乐资源
namespace app\api\v2\goods\controllers;

class Goods extends \app\api\Controller
{
	public function actionList()
	{
	}

	public function actionDetail()
	{
	}

	public function actionSku()
	{
	}

	public function actionFittings()
	{
	}
}

?>
