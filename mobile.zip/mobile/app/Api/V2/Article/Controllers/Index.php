<?php
//多点乐资源
namespace app\api\v2\article\controllers;

class Index extends \app\api\Controller
{
	public function actionIndex()
	{
	}
}

?>
