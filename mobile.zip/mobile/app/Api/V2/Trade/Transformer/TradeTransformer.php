<?php
//多点乐资源
namespace app\api\v2\trade\transformer;

class TradeTransformer extends \App\Api\Foundation\Transformer
{
	public function transform(array $map)
	{
		return array();
	}
}

?>
