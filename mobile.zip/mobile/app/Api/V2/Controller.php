<?php
//多点乐资源
namespace app\api\v2;

class Controller extends \App\Http\Base\Controllers\Frontend
{}

?>
