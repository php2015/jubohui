<?php
//多点乐资源
namespace App\Api\Controllers;

class HomeController extends Controller
{
	public function index()
	{
		return array('home' => 'array');
	}
}

?>
