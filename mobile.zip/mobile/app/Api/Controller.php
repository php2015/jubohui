<?php
//多点乐资源
namespace app\api;

class Controller extends \App\Http\Base\Controllers\Frontend
{}

?>
