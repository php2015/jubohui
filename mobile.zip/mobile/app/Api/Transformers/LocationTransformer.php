<?php
//多点乐资源
namespace App\Api\Transformers;

class LocationTransformer extends \League\Fractal\TransformerAbstract
{
	public function transform()
	{
		return array();
	}
}

?>
