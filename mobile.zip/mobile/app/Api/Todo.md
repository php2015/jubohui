小程序页面规划
=======

1. 首页(店铺)

2. 分类

3. 购物车

4. 我的

5. 商品列表

6. 商品详情

7. 订单提交

会员中心
1. 订单列表（待支付、待收货、待评价、全部订单）（订单详情）

2. 我的钱包（）

3. 收货地址

4. 我的收藏

5. 我的优惠券


参考项目：

1. 酷客多
2. 拼多多
3. 周黑鸭官方商城


项目难点：
1. 收款方为平台或商家
2. 平台接口需要升级为https
3. 进入后要求先关联手机号码


项目版本库： 
1. 平台版：https://git.oschina.net/dscmall/mini-apps.git
2. 商家版：https://git.oschina.net/dscmall/mini-apps-seller.git
3. 门店版：https://git.oschina.net/dscmall/mini-apps-store.git
